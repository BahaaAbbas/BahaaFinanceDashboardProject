import React from 'react'
import { useTheme } from '../contexts/ThemeContext'

const Home = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div>


      <button
        onClick={toggleTheme}
        className="p-2 rounded-md border border-gray-300 dark:border-gray-600"
      >
        {theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode"}
      </button>
      <h2>Yes , follow</h2>
      <h2 className="text-purple-600 dark:text-yellow-400">Customized Color for H2</h2>
  <h1 className="text-blue-500 dark:text-green-500">Customized Color for H1</h1>
  <h2 className="text-pink-600">Another Custom Color for H2</h2>
    </div>

  );
}

export default Home